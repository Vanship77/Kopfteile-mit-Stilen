package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelos.Productos;
import servicios.ProductoService;
import servicios.ProductosServiceImplement;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet({"/Productos.xls", "/productohmtl"})
public class Controlador extends HttpServlet {
    private final ProductoService servicios = new ProductosServiceImplement();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Productos> productos = servicios.listar();
        String servletPath = req.getServletPath();
        boolean xls = servletPath.endsWith(".xls");

        if (xls) {
            resp.setContentType("application/vnd.ms-excel");
            resp.setHeader("Content-disposition", "attachment; filename=producto.xls");
        }

        try (PrintWriter out = resp.getWriter()) {
            if (!xls) {
                generarHtml(out, productos, req);
            } else {
                generarExcel(out, productos);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Manejo de errores simple, considera mejorar esto
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al procesar la solicitud.");
        }
    }

    private void generarHtml(PrintWriter out, List<Productos> productos, HttpServletRequest req) {
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"UTF-8\">");
        out.println("<title>Lista de Productos</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Información del Servlet</h1>");
        out.println("<table border=1>");
        out.println("<thead><tr><td>ID</td><td>Nombre</td><td>Categoría</td><td>Precio</td></tr></thead>");
        out.println("<tbody>");

        for (Productos producto : productos) {
            out.println("<tr>");
            out.println("<td>" + producto.getIdProducto() + "</td>");
            out.println("<td>" + producto.getNombre() + "</td>");
            out.println("<td>" + producto.getCategoria() + "</td>");
            out.println("<td>" + producto.getPrecio() + "</td>");
            out.println("</tr>");
        }

        out.println("</tbody>");
        out.println("</table>");
        out.println("<a href=\"index.html\">Volver</a>");
        out.println("<p><a href=\"" + req.getContextPath() + "/Productos.xls\">Descargar Excel</a></p>");
        out.println("</body>");
        out.println("</html>");
    }

    private void generarExcel(PrintWriter out, List<Productos> productos) {
        // Salida en formato Excel (tabulada)
        out.println("ID\tNombre\tCategoría\tPrecio\n");

        for (Productos producto : productos) {
            out.println(producto.getIdProducto() + "\t" + producto.getNombre() + "\t"
                    + producto.getCategoria() + "\t" + producto.getPrecio() + "\n");
        }
    }
}