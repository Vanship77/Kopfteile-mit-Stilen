package modelos;

import servicios.ProductosServiceImplement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/Productos")
public class ProductoService extends HttpServlet {
    private final ProductosServiceImplement productosService = new ProductosServiceImplement();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Productos> productos = productosService.listar();

        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"UTF-8\">");
        out.println("<title>Lista de Productos</title>");
        out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class=\"container mt-5\">");
        out.println("<h1 class=\"text-center\">Lista de Productos</h1>");
        out.println("<table class=\"table table-striped\">");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Nombre</th>");
        out.println("<th>Categoría</th>");
        out.println("<th>Precio</th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tbody>");

        for (Productos producto : productos) {
            out.println("<tr>");
            out.println("<td>" + producto.getIdProducto() + "</td>");
            out.println("<td>" + producto.getNombre() + "</td>");
            out.println("<td>" + producto.getCategoria() + "</td>");
            out.println("<td>" + producto.getPrecio() + "</td>");
            out.println("</tr>");
        }

        out.println("</tbody>");
        out.println("</table>");
        out.println("<a href=\"login.html\" class=\"btn btn-secondary\">Cerrar Sesión</a>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}