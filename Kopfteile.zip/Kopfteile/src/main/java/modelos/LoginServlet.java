package modelos;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    // Credenciales definidas de forma estática
    private static final String USUARIO = "vanship77";
    private static final String PASSWORD = "vegetta777";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Obtener los parámetros del formulario
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // Comprobamos si las credenciales son correctas
        if (username != null && password != null && username.equals(USUARIO) && password.equals(PASSWORD)) {
            // Si las credenciales son correctas
            resp.setContentType("text/html;charset=UTF-8");
            PrintWriter out = resp.getWriter();

            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<title>Login Success</title>");


            out.println("</head>");
            out.println("<body>");
            out.println("<h1>¡Bienvenido! Has iniciado sesión correctamente.</h1>");
            out.println("</body>");
            out.println("</html>");
        } else {
            // Si las credenciales son incorrectas
            resp.setContentType("text/html;charset=UTF-8");
            PrintWriter out = resp.getWriter();

            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<title>Login Error</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Error de Login</h1>");
            out.println("<p>Lo sentimos, las credenciales que has introducido no son correctas. Por favor, inténtalo de nuevo.</p>");
            out.println("<a href='login.html'>Volver al login</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
