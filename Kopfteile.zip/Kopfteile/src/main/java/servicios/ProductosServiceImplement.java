package servicios;

import modelos.Productos;
import java.lang.reflect.Array;
import java.util.List;
import java.util.Arrays;

public class ProductosServiceImplement implements ProductoService{
    @Override
    public List<Productos> listar() {
        return Arrays.asList (new Productos(1,"Laptop","tecnologia",100.00),
                new Productos(2,"Telefono","tecnologia",450.00),
                new Productos(3,"Tablet","tecnologia",580.00),
                new Productos(4,"Impresora","tecnologia",250.00),
                new Productos(5,"Audifonos","tecnologia",76.00),
                new Productos(6,"PC","tecnologia",1584.00));




    }
}
