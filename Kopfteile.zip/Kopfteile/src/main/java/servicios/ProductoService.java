package servicios;
import modelos.Productos;


import java.util.List;


public interface ProductoService {
    public List<Productos> listar();
}
